# Paramjeet Singh — Data Analyst Portfolio

## Requirements
- Node.js 18.17+ (Node.js 20 LTS recommended)
- npm

## Run locally
1. Extract this folder.
2. Open a terminal in the project folder (the folder containing `package.json`).
3. Run `npm install`.
4. Run `npm run dev` and open the local URL shown in the terminal.
5. Run `npm run build` before deployment.

## Important notes
- The contact details and social profile links are taken from the original project. Please verify them before publishing.
- Project cards link to the GitHub profile because individual repository URLs were not included in the supplied project. Replace those links with the exact repository URL for each project when available.
- “View Screenshot” opens the local dashboard image; it is not an interactive hosted dashboard.
- Add your own project repositories, datasets (only when safe to share), analysis steps and verified findings before sending this portfolio to recruiters.
- `.next`, `node_modules`, and the duplicated nested project were excluded from this cleaned archive.
