"use client"

import { Button } from "@/components/ui/button"
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react"

const EMAIL = "paramjeetslathiasingh@gmail.com"
const GITHUB = "https://github.com/ParamjeetSlathia"
const LINKEDIN = "https://www.linkedin.com/in/paramjeet-singh-slathia-183535322/"

export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted">
      <div className="container mx-auto px-4 py-24">
        <div className="max-w-4xl mx-auto text-center">
          <img
            src="/param2.jpg"
            alt="Portrait of Paramjeet Singh"
            width={192}
            height={192}
            fetchPriority="high"
            className="w-40 h-40 md:w-48 md:h-48 object-cover rounded-full mx-auto mb-8 border-4 border-primary shadow-lg"
          />
          <p className="text-lg font-medium text-primary mb-3">Hello, I’m</p>
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">Paramjeet Singh</h1>
          <h2 className="text-2xl md:text-3xl mb-6 text-primary font-semibold">Data Analyst | MIS Reporting & Business Intelligence</h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-3xl mx-auto leading-relaxed text-pretty">
            I turn business data into useful insights through Excel, SQL, Power BI and reporting automation. I enjoy analysing trends, building clear dashboards and helping teams make data-informed decisions. My experience in MIS reporting also helps me connect analysis with day-to-day business operations.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <Button size="lg" onClick={() => scrollToSection("projects")} className="text-lg px-8 py-3">View My Projects</Button>
            <Button variant="outline" size="lg" onClick={() => scrollToSection("contact")} className="text-lg px-8 py-3">Contact Me</Button>
          </div>
          <div className="flex items-center justify-center gap-6 mb-10">
            <a aria-label="GitHub profile" href={GITHUB} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><Github className="h-6 w-6" /></a>
            <a aria-label="LinkedIn profile" href={LINKEDIN} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><Linkedin className="h-6 w-6" /></a>
            <a aria-label="Send email" href={`mailto:${EMAIL}`} className="text-muted-foreground hover:text-primary transition-colors"><Mail className="h-6 w-6" /></a>
          </div>
          <button type="button" aria-label="Scroll to skills" onClick={() => scrollToSection("skills")} className="animate-bounce text-primary hover:text-accent transition-colors"><ArrowDown className="h-8 w-8" /></button>
        </div>
      </div>
    </section>
  )
}
