export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-8">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="mb-4">
            <h3 className="text-2xl font-bold mb-2">Paramjeet Singh</h3>
            <p className="text-primary-foreground/80">Data Analyst | MIS Reporting & Business Intelligence</p>
          </div>

          <div className="border-t border-primary-foreground/20 pt-4">
            <p className="text-primary-foreground/80">Copyright 2026. All Rights Reserved</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
