import { Card, CardContent } from "@/components/ui/card"

const skillGroups = [
  { title: "Data Analysis", skills: ["Advanced Excel", "SQL", "Power BI", "Data Cleaning", "Data Visualization", "KPI Reporting"] },
  { title: "Automation & Reporting", skills: ["Google Sheets", "Google Apps Script", "Dashboard Automation", "MIS Reporting"] },
  { title: "Technical Skills", skills: ["Python (Basic)", "JavaScript", "React", "HTML & CSS", "Git"] },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Skills & Tools</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">Tools I use for data analysis, MIS reporting, dashboard creation and workflow automation.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {skillGroups.map((group) => (
              <Card key={group.title} className="h-full">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">{group.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {group.skills.map((skill) => <span key={skill} className="px-3 py-2 rounded-lg bg-primary/10 text-primary text-sm font-medium">{skill}</span>)}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
