"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"

const GITHUB = "https://github.com/ParamjeetSlathia"

type Project = {
  title: string
  description: string
  tech: string[]
  image: string
}

const projectGroups: { id: string; label: string; title: string; description: string; projects: Project[] }[] = [
  {
    id: "power-bi",
    label: "E-commerce Analysis",
    title: "E-commerce Sales Analysis",
    description: "Explore sales performance, product contribution and customer purchasing trends using dashboard-led analysis.",
    projects: [
      {
        title: "E-commerce Sales Analysis",
        description: "A sales analysis project focused on revenue trends, top-selling products and customer purchasing behaviour. Add your key findings and KPI definitions when publishing the project.",
        tech: ["Excel", "SQL", "Power BI"],
        image: "/ecommerce.png",
      },
      {
        title: "E-commerce Sales Dashboard",
        description: "A dashboard concept for monitoring sales KPIs and comparing performance over time. Replace or supplement the screenshot with your final interactive dashboard.",
        tech: ["Excel", "Power BI"],
        image: "/ecommercesale.png",
      },
    ],
  },
  {
    id: "excel",
    label: "Excel Dashboard",
    title: "Sales Reporting Dashboard",
    description: "Excel reporting for monthly performance, revenue summaries and product-level comparisons.",
    projects: [
      {
        title: "Sales Performance Dashboard",
        description: "An Excel dashboard using charts and KPI summaries to review sales performance. Include the dataset, formulas and business insights in the repository for reproducibility.",
        tech: ["Advanced Excel", "PivotTables", "Charts"],
        image: "/dashboard.png",
      },
      {
        title: "Sales Trends Dashboard",
        description: "A visual summary of sales trends and product/category performance. Use the screenshot as a preview; the linked GitHub profile contains your public repositories.",
        tech: ["Excel", "Data Visualization"],
        image: "/dashboardsale.png",
      },
    ],
  },
]

export function ProjectsSection() {
  const [activeTab, setActiveTab] = useState(projectGroups[0].id)
  const activeGroup = projectGroups.find((group) => group.id === activeTab) ?? projectGroups[0]

  return (
    <section id="projects" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Data Analytics Projects</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
              Selected work using Excel, SQL and Power BI to explore business performance and communicate insights. Each project should include its dataset, methodology, findings and limitations.
            </p>
            <a href={GITHUB} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-primary hover:text-accent underline font-medium">
              <Github className="h-4 w-4" /> View my GitHub profile <ExternalLink className="h-3 w-3" />
            </a>
          </div>

          <div className="flex flex-wrap justify-center gap-3 mb-10" role="tablist" aria-label="Project categories">
            {projectGroups.map((group) => (
              <Button key={group.id} type="button" role="tab" aria-selected={activeTab === group.id} variant={activeTab === group.id ? "default" : "outline"} onClick={() => setActiveTab(group.id)} className="text-sm md:text-base">
                {group.label}
              </Button>
            ))}
          </div>

          <div className="mb-8 text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-3">{activeGroup.title}</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">{activeGroup.description}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {activeGroup.projects.map((project) => (
              <Card key={project.title} className="group overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <a href={project.image} target="_blank" rel="noopener noreferrer" aria-label={`Open screenshot for ${project.title}`} className="block aspect-video overflow-hidden bg-muted">
                  <img src={project.image} alt={`${project.title} preview`} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                </a>
                <CardHeader>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{project.title}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">{project.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => <span key={tech} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">{tech}</span>)}
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Button asChild size="sm" variant="outline" className="gap-2">
                      <a href={GITHUB} target="_blank" rel="noopener noreferrer"><Github className="h-4 w-4" /> GitHub Profile</a>
                    </Button>
                    <Button asChild size="sm" className="gap-2">
                      <a href={project.image} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-4 w-4" /> View Screenshot</a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <p className="text-sm text-muted-foreground text-center mt-8">Note: screenshot links open the included image files. Replace the GitHub profile links with individual project repositories when those repositories are available.</p>
        </div>
      </div>
    </section>
  )
}
