import { Mail, Phone, MapPin, Linkedin, Github, ExternalLink } from "lucide-react"

const EMAIL = "paramjeetslathiasingh@gmail.com"
const PHONE = "+919797418611"
const GITHUB = "https://github.com/ParamjeetSlathia"
const LINKEDIN = "https://www.linkedin.com/in/paramjeet-singh-slathia-183535322/"

const contacts = [
  { label: "Email", value: EMAIL, href: `mailto:${EMAIL}`, icon: Mail },
  { label: "Phone", value: "+91 97974 18611", href: `tel:${PHONE}`, icon: Phone },
  { label: "GitHub", value: "github.com/ParamjeetSlathia", href: GITHUB, icon: Github },
  { label: "LinkedIn", value: "Connect on LinkedIn", href: LINKEDIN, icon: Linkedin },
]

export function ContactSection() {
  return (
    <section id="contact" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Get In Touch</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">I’m open to Data Analyst, MIS and business reporting opportunities. Feel free to contact me.</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            {contacts.map(({ label, value, href, icon: Icon }) => {
              const external = href.startsWith("https://")
              return (
                <a key={label} href={href} target={external ? "_blank" : undefined} rel={external ? "noopener noreferrer" : undefined} className="flex items-center gap-4 rounded-xl border bg-background p-5 hover:border-primary hover:shadow-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
                  <span className="w-12 h-12 shrink-0 bg-primary/10 rounded-lg flex items-center justify-center"><Icon aria-hidden="true" className="h-6 w-6 text-primary" /></span>
                  <span className="min-w-0"><span className="block font-semibold">{label}</span><span className="block text-sm text-muted-foreground break-words">{value}</span></span>
                  {external && <ExternalLink aria-hidden="true" className="h-4 w-4 ml-auto shrink-0 text-muted-foreground" />}
                </a>
              )
            })}
          </div>
          <p className="text-center text-sm text-muted-foreground mt-8"><MapPin className="inline h-4 w-4 mr-1" />Jammu, India · Open to suitable opportunities</p>
        </div>
      </div>
    </section>
  )
}
