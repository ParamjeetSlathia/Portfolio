import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import { ThemeProvider } from "@/components/theme-provider"
import "./globals.css"

export const metadata: Metadata = {
  title: "Paramjeet Singh | Data Analyst & MIS Reporting",
  description: "Portfolio of Paramjeet Singh showcasing data analysis, MIS reporting, Excel, SQL, Power BI dashboards and reporting automation.",
  openGraph: {
    title: "Paramjeet Singh | Data Analyst & MIS Reporting",
    description: "Data analysis, business reporting, dashboard development and automation portfolio.",
    type: "website",
  },
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <Suspense fallback={null}>{children}</Suspense>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
